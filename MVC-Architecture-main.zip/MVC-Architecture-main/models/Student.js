const mongoose = require("mongoose")

const studentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Please provide a student name"],
      trim: true,
      minlength: [2, "Name must be at least 2 characters long"],
      maxlength: [50, "Name cannot exceed 50 characters"],
    },
    age: {
      type: Number,
      required: [true, "Please provide student age"],
      min: [1, "Age must be at least 1"],
      max: [120, "Age cannot exceed 120"],
    },
    course: {
      type: String,
      required: [true, "Please provide a course name"],
      trim: true,
      minlength: [2, "Course name must be at least 2 characters long"],
      maxlength: [100, "Course name cannot exceed 100 characters"],
    },
  },
  {
    timestamps: true,
  },
)

module.exports = mongoose.model("Student", studentSchema)
